import 'package:flutter/material.dart';
import '../../viewmodels/auth_viewmodel.dart';
import '../../viewmodels/home_viewmodel.dart';

class HomePageLandscape extends StatelessWidget {
  final AuthViewModel authViewModel;
  final HomeViewModel homeViewModel;
  final int selectedIndex;
  final void Function(int) onBottomNavTap;
  final VoidCallback showAddFoodOptions;
  final Widget Function(String?) buildProfileImage;
  final Widget Function(String, String, Color) buildNutrientInfo;

  const HomePageLandscape({
    Key? key,
    required this.authViewModel,
    required this.homeViewModel,
    required this.selectedIndex,
    required this.onBottomNavTap,
    required this.showAddFoodOptions,
    required this.buildProfileImage,
    required this.buildNutrientInfo,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final currentUser = authViewModel.currentUser;
    final todaysMeals = homeViewModel.todaysMeals;
    final totalCalories = homeViewModel.totalCalories;

    String getDisplayName() {
      if (currentUser?.displayName != null &&
          currentUser!.displayName!.isNotEmpty) {
        return currentUser!.displayName!.split(' ').first;
      }
      return "User";
    }

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Row(
          children: [
            // Left: Meals List
            Expanded(
              flex: 2,
              child: ListView(
                padding: const EdgeInsets.all(24),
                children: [
                  const Text(
                    "Today's Meals",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  ...todaysMeals.map((meal) => Card(
                        margin: const EdgeInsets.symmetric(vertical: 8),
                        child: ListTile(
                          title: Text(meal.name),
                          subtitle: Text(meal.description ?? 'No description'),
                          trailing: Text('${meal.calories.toInt()} cal'),
                        ),
                      )),
                  const SizedBox(height: 16),
                  ElevatedButton.icon(
                    onPressed: showAddFoodOptions,
                    icon: const Icon(Icons.add),
                    label: const Text('Add Meal'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFD6F36B),
                      foregroundColor: Colors.black,
                    ),
                  ),
                ],
              ),
            ),
            // Center: User Info & Nutrients
            Expanded(
              flex: 2,
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        buildProfileImage(currentUser?.photoURL),
                        const SizedBox(width: 16),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Welcome,',
                              style: TextStyle(fontSize: 16, color: Colors.black54),
                            ),
                            Text(
                              getDisplayName(),
                              style: const TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        const Spacer(),
                        IconButton(
                          icon: const Icon(Icons.settings),
                          onPressed: () => Navigator.pushNamed(context, '/profile'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 32),
                    Text(
                      "Today's Calories Consumed: $totalCalories",
                      style: const TextStyle(
                        color: Color(0xFFE57373),
                        fontWeight: FontWeight.w600,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        buildNutrientInfo(
                          'Protein',
                          '${homeViewModel.proteinGrams.round()}g',
                          Colors.blue,
                        ),
                        buildNutrientInfo(
                          'Carbs',
                          '${homeViewModel.carbsGrams.round()}g',
                          Colors.orange,
                        ),
                        buildNutrientInfo(
                          'Fat',
                          '${homeViewModel.fatGrams.round()}g',
                          Colors.red,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            // Right: Daily Goal Card
            Expanded(
              flex: 2,
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            const Color(0xFFD6F36B).withOpacity(0.8),
                            const Color(0xFFD6F36B).withOpacity(0.6),
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'Daily Goal',
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.black54,
                                    ),
                                  ),
                                  Text(
                                    '$totalCalories / 2000 cal',
                                    style: const TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                              CircularProgressIndicator(
                                value: totalCalories / 2000,
                                backgroundColor: Colors.white.withOpacity(0.3),
                                valueColor: const AlwaysStoppedAnimation<Color>(
                                  Colors.black,
                                ),
                                strokeWidth: 6,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: selectedIndex,
        onTap: onBottomNavTap,
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.white,
        selectedItemColor: const Color(0xFFFF7A4D),
        unselectedItemColor: const Color(0xFFB0B0B0),
        elevation: 0,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today),
            label: 'Nutrition',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add_circle),
            label: 'Add',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFFD6F36B),
        onPressed: () => Navigator.pushNamed(context, '/scanner'),
        child: const Icon(Icons.camera_alt, color: Colors.black, size: 28),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
} 